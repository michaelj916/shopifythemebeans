(function () {
  'use strict';

  var example = function example() {
    console.info('This is an example to show the use of import/export syntax.');
  };

  example();
})();
//# sourceMappingURL=theme.js.map
